# RELATÓRIO — SISTEMA DE CHAMADOS DE SUPORTE TÉCNICO

## Objetivo
Centralizar solicitações de suporte técnico.

## Perfis
- Funcionário: apenas abre chamados.
- Técnico: acessa e atende os chamados.

## Fluxo principal
Funcionário abre o chamado; o sistema gera o número e deixa o status como Aberto. O técnico acessa o chamado, define responsável, altera o status para Em atendimento, registra a solução e encerra.

## Requisitos utilizados
RF01 — Autenticação e perfil.
RF02 — Registro de chamado.
RF04 — Definição de prioridade.
RF05 — Definição de responsável.
RF06 — Atualização de status.
RF07 — Histórico.
RF08 — Encerramento com solução.

## Limitação
O MVP utiliza LocalStorage e autenticação simples, adequada para demonstração acadêmica.

## Conclusão
O MVP demonstra o fluxo principal de abertura e atendimento de chamados de forma simples e funcional.
